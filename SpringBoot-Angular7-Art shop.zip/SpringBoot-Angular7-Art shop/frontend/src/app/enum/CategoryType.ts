export enum CategoryType {
    "Acrylic painting", "Digital painting", "Sand painting", "Water painting"
}
